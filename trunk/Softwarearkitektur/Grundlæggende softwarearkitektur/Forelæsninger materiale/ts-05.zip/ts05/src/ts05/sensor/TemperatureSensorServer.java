package ts05.sensor;

import java.rmi.*;
import java.rmi.server.*;


/** 
    The Temperature server models a temperature sensor in the
    field. It instantiates a temperature sensor object, binds it
    to the name registry, and runs the sensor as a thread.
    
    @author Henrik B�rbak Christensen - (c) Imhotep 2003

*/
  
public class TemperatureSensorServer {

  public static void main(String[] args) {
    // define where the rmi registry is located...
    String registry_host = "//localhost/";
    System.out.println( "Using registry at "+registry_host );
    try {
      System.out.println( "Initializing  ..." );
      if (System.getSecurityManager() == null) {
        System.setSecurityManager(new RMISecurityManager());
      }
      System.out.println( "SecurityManager installed..." );
      
      // create a temperature sensor object representing the TS-05
      TemperatureSensorImpl 
        tss = new TemperatureSensorImpl();
      
      System.out.println( "Sensor object has been bound to do" );
      String name = registry_host+"section1";
      Naming.rebind(name, tss);
      System.out.println( "Sensor object has been bound to name: "+name );
        
      // make tss run in its own thead...
      Thread t = new Thread( tss );
      t.start();
      System.out.println( "Sensors are up and running..." ); 
    } catch (Exception e) {
      System.err.println( e );
      System.exit(1);
    }
  }
}
