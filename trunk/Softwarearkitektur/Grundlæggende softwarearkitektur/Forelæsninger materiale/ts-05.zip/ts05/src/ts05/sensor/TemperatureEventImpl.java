package ts05.sensor;

import java.rmi.Remote;
import java.rmi.RemoteException;


/** 
    Event object implementation holding a single temperature reading.
    This (immutable object) is sent to every listener that listens to
    a TemperatureSensor whenever the sensor has sampled a new
    temperature reading.
    
    @author (c) Henrik B�rbak Christensen - Imhotep 2003

*/
  
public class TemperatureEventImpl implements TemperatureEvent {

  /** the temperature reading */
  private double reading;

  /** construct an immutable temperature event holding the
      temperature given as parameter.
      @param reading the temperature in Celcius 
  */
  public TemperatureEventImpl(double reading) {
    this.reading = reading;
  } 

  public double getReading() { return reading; }
}
