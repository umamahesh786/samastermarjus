package ts05.monitor;

import java.rmi.*;
import java.io.*;

import ts05.sensor.*;

/** 
    Temperature monitor attaches itself to a temperature sensor
    and monitors all readings by outputting on the console.
    
    @author Henrik B�rbak Christensen - (c) Imhotep 2003

*/

public class TemperatureMonitor {

  /** instantiate the monitor */
  public static void main(String[] args) {

    if (System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }
    
    String registry_host = "//localhost/";

    System.out.println( "Using registry at "+registry_host );

    try {
      // get the temperature sensor object reference from the
      // RMI object request broker...
        String name = registry_host+"section1";
        System.out.println( "Looking up object reference: "+name );
        TemperatureSensor ts = (TemperatureSensor) Naming.lookup(name);
        
        System.out.println( "Located sensor object..." );

        // Create a local temperature listener object
        // (observer pattern 'observer'-role)
        // and register it at the temperature sensor.
        // The object refers to the counter object 
        TemperatureListener tl = new TemperatureListenerImpl();
        System.out.println( "Created listener..." );
        ts.addTemperatureListener(tl);
        System.out.println( "Added listener object to sensor" );
        
        // wait for callbacks
        System.out.println( "Finished; awaiting callbacks..." );
        
        // tricks-of-the-trade way of waiting on incoming calls...
        java.lang.Object sync = new java.lang.Object();
        synchronized (sync) {
          sync.wait();
        }
    } catch (Exception e) {
      System.err.println("TemperatureMonitor exception: " + 
                         e.getMessage());
      e.printStackTrace();
    }
  }
}

