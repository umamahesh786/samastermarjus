package ts05.sensor;

import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

/** 
    Temperature Sensor implementation.
    Implemented in its own thread.
    
    @author (c) Imhotep 2003 - Henrik B�rbak Christensen

*/
  
public class TemperatureSensorImpl extends UnicastRemoteObject 
  implements TemperatureSensor, Runnable {

  private List listenerList;

  public TemperatureSensorImpl() throws RemoteException {
    super();
    listenerList = new Vector();
  }
  
  private double temperature = 80.0;

  public void run() {
    while ( true ) {
      // wait 0.1 sec
      try {
        Thread.sleep(100);
      } catch ( InterruptedException e ) {}
      // make a new temperature reading
      temperature += Math.random()-0.49;
      notifyAllListeners();
    }
  }
  
  public synchronized void addTemperatureListener( TemperatureListener tl ) 
    throws RemoteException {
    listenerList.add( tl );
  }
  
  private int notifications=0;
  private void notifyAllListeners() {
    TemperatureEvent te = new TemperatureEventImpl(temperature);
    Iterator i = listenerList.iterator();
    while ( i.hasNext() ) {
      TemperatureListener tl = (TemperatureListener) i.next();
      try {
        tl.temperatureSampled( te );
      } catch ( RemoteException exc ) {
        System.out.println( ""+exc );
        System.exit(1);
      }
    }
    System.out.println( "Broadcasted temperature "+temperature );

  }

}
