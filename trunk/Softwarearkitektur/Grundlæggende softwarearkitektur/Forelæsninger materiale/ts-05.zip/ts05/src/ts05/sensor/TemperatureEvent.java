package ts05.sensor;

import java.rmi.Remote;
import java.rmi.RemoteException;


/** 
    Event object holding a single temperature reading broadcast
    from a temperature sensor
    
    @author Henrik B�rbak Christensen - (c) Imhotep 2003

*/
  
  
public interface TemperatureEvent extends java.io.Serializable {

  /** return the temperature reading that this event represents.
      @return the temperature reading measured in Celcius 
  */
  public double getReading();
}
