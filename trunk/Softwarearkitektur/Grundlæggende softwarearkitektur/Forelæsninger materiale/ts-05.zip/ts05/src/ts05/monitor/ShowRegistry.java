package ts05.monitor;

import java.rmi.*;

/** 
    Show names bound in the registry
    
    @author Henrik B�rbak Christensen - (c) Imhotep 2003

*/

public class ShowRegistry {

  public static void main(String[] args) {
    if (args.length != 1) {
      System.out.println( "Wrong number of parameters:" );
      System.out.println( " 1. parameter: host where registry is running" );
      System.exit(0);
    } 

    if (System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }
    try {
      String [] objs = Naming.list(args[0]);

      for ( int i = 0; i < objs.length; i++ ) {
        System.out.println( "- "+objs[i] ); 
      }
    } catch (Exception e) {
      System.err.println("ShowRegistry exception: " + 
                         e.getMessage());
      e.printStackTrace();
    }
  }
}


