package ts05.sensor;

import java.rmi.Remote;
import java.rmi.RemoteException;


/** 
    This interface represents the contract of a simple
    temperature sensor in the field.

    <p> The sensor is modelled as a separate, distributed, process
    that continuously broadcasts temperature values to any interested
    entity. It acts as the 'subject' role in the GoF observer pattern.

    <p>
    An entity register its interest in temperature data by
    adding itself as recipant of temperature data. It must
    do so by implementing the <tt>TemperatureListener</tt> contract, 
    and register by calling the <tt>addTemperatureListener</tt> method.
    
    @author Henrik B�rbak Christensen / (c) Imhotep 2003

    @see TemperatureListener

*/
  
  
public interface TemperatureSensor extends Remote {
  /** register a listener to receive temperature data.
      @param tl the temperature listener instance to broadcast to.
  */
  public void addTemperatureListener( TemperatureListener tl ) 
    throws RemoteException;
}

