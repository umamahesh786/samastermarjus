package ts05.monitor;

import java.rmi.*;
import java.rmi.server.*;

import ts05.sensor.*;

/** Implementation of a temperature listener that output
    received values on the console.

    @author Henrik B�rbak Christensen - (c) Imhotep 2003

*/
    
public class TemperatureListenerImpl extends UnicastRemoteObject 
  implements Remote, TemperatureListener {
  
  public TemperatureListenerImpl() throws RemoteException {
    super();
  }

  /** outputs the temperature sampled on the console */
  public void temperatureSampled( TemperatureEvent t_event )
    throws RemoteException {
    double T = t_event.getReading();
    System.out.println( "Received reading="+T );
  }
}
