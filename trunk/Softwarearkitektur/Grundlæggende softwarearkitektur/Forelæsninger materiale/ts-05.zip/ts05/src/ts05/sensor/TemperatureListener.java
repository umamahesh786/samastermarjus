package ts05.sensor;

import java.rmi.Remote;
import java.rmi.RemoteException;

/** 
    An object that is interested in receiving temperature data must
    implement this interface, and register itself as listener on
    a temperature sensor.
    
    <p>
    Any object implementing this interface acts as the 'observer'
    role from the GoF observer pattern.

    @author Henrik B�rbak Christensen / (c) Imhotep 2003

*/
  
  
public interface TemperatureListener extends Remote {

  /** this method is invoked every time a temperature sensor
      broadcasts a temperature 
      @param t_event an object encapsulating the temperature value
      sampled.
  */ 
  public void temperatureSampled( TemperatureEvent t_event )
    throws RemoteException;
}
