/**
 * InventoryBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.pos;

public class InventoryBindingImpl implements com.pos.InventoryPort{
    public java.lang.String executeUpdate(com.pos.Request parameter) throws java.rmi.RemoteException {
        return parameter.getCommand() + " " + parameter.getValue();
    }

}
