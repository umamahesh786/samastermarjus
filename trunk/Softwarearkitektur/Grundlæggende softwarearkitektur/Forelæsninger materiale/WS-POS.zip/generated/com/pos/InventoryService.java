/**
 * InventoryService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.pos;

public interface InventoryService extends javax.xml.rpc.Service {
    public java.lang.String getInventoryPortAddress();

    public com.pos.InventoryPort getInventoryPort() throws javax.xml.rpc.ServiceException;

    public com.pos.InventoryPort getInventoryPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
