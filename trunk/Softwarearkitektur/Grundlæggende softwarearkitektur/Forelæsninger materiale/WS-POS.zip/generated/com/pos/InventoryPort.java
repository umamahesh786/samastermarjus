/**
 * InventoryPort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.pos;

public interface InventoryPort extends java.rmi.Remote {
    public java.lang.String executeUpdate(com.pos.Request parameter) throws java.rmi.RemoteException;
}
