Simple Point-Of-Sales (POS) web service example for ATiSA
=========================================================
Requirements
------------
- Java 5 or later
- Ant

Running
-------
The system consists of a client and a server, where the client makes one web service call to the server

To run the server do:

1) ant web
2) ant runServer
3) ant install

(Step 1) is only necessary when the service changes)

To run the client do (on the same machine):

1) ant runClient

Monitoring
----------
To monitor the web service calls, do

1) ant tcpmon
2) configure TCP Monitor to be a proxy for the web service (i.e., the client should invoke the service 
   at a port where the TCP Monitor forwards traffic to the server port)
   
Contact
-------
klaus.m.hansen@daimi.au.dk
