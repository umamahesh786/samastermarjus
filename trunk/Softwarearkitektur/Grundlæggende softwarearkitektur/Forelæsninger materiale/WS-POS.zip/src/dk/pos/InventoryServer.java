/*
 * 
 * Embedded Jetty web server that loads the Hospital web service
 * servlet running on Axis
 * 
 * The actual web service endpoint implementation can be found in
 * /generated/org/ehr/HospitalBindingImpl.java
 * 
 */
package dk.pos;

import org.mortbay.jetty.*;

public class InventoryServer {
	
	public InventoryServer (int portNumber) throws Exception {
		final int _portNumber = portNumber;
		// Create and start Jetty web server
		Server server = new Server();
		server.addListener(":" + _portNumber);
		// - add the ddist.war web application
		server.addWebApplication("/axis", "web/pos.war");
		server.start();		
		
		System.out.println(getClass().getName() + " started on port " + _portNumber);
	}
	
	public static void main(String[] args) {
		try {
			int portNumber = 8080;
			if (args.length == 1) {
				portNumber = Integer.parseInt(args[0]);
			}
			new InventoryServer(portNumber);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
