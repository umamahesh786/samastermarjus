/*
 * 
 * This example uses Axis-generated stub code to interact with the Hospital
 * web service
 * 
 * Most of the work is done in build.xml
 *  
 */
package dk.pos;

import java.net.URL;

import com.pos.InventoryPort;
import com.pos.InventoryService;
import com.pos.InventoryServiceLocator;
import com.pos.Request;

public class InventoryClient {
	public InventoryClient(String host) throws Exception {
		// Find the web service endpoint
		InventoryService service = new InventoryServiceLocator();
		InventoryPort port = service.getInventoryPort(new URL(host));
		// Do a simple interaction with the web service
		Request request = new Request();
		request.setCommand("Buy");
		request.setValue("SAIP");
		System.out.println("Updated: " + port.executeUpdate(request));
	}
	
	public static void main(String[] args) {
		try {
			String host = "http://localhost:8080/axis/services/InventoryPort";
			if (args.length == 1) {
				host = args[0];
			}
			new InventoryClient(host);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
