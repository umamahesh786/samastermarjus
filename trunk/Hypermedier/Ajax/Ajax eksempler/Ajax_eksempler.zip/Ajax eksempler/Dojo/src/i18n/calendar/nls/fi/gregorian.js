/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

({"field-weekday":"viikonpäivä","dateFormat-medium":"d.M.yyyy","field-second":"sekunti","field-week":"viikko","pm":"ip.","timeFormat-full":"H.mm.ss v","months-standAlone-narrow":["T","H","M","H","T","K","H","E","S","L","M","J"],"am":"ap.","days-standAlone-narrow":["S","M","T","K","T","P","L"],"field-year":"vuosi","eras":["eKr.","jKr."],"field-minute":"minuutti","timeFormat-medium":"H.mm.ss","field-hour":"tunti","dateFormat-long":"d. MMMM'ta 'yyyy","field-day":"päivä","field-dayperiod":"ap/ip-valinta","field-month":"kuukausi","dateFormat-short":"d.M.yyyy","months-format-wide":["tammikuu","helmikuu","maaliskuu","huhtikuu","toukokuu","kesäkuu","heinäkuu","elokuu","syyskuu","lokakuu","marraskuu","joulukuu"],"field-era":"aikakausi","timeFormat-short":"H.mm","months-format-abbr":["tammi","helmi","maalis","huhti","touko","kesä","heinä","elo","syys","loka","marras","joulu"],"timeFormat-long":"'klo 'H.mm.ss","days-format-wide":["sunnuntai","maanantai","tiistai","keskiviikko","torstai","perjantai","lauantai"],"dateFormat-full":"EEEE'na 'd. MMMM'ta 'yyyy","field-zone":"aikavyöhyke","days-format-abbr":["su","ma","ti","ke","to","pe","la"]})