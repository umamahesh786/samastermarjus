<ul class="menulist">
	<li>&nbsp;</li>
	<li>Categories</li>
	<li>
		<ul class="menusublist">
			<li><a href="index.php">All</a></li>
			<li><a href="index.php?category=Fun stuff">Fun stuff</a></li>
			<li><a href="index.php?category=Serious stuff">Serious stuff</a></li>
			<li><a href="index.php?category=Other stuff">Other stuff</a></li>
		</ul>
	</li>
	<li>&nbsp;</li>
	<li>Administration</li>
	<li>
		<ul class="menusublist">
			<li><a href="none">Login</a></li>
			<li><a href="add_post.php">Add post</a></li>
			<li><a href="none">Manage categories</a></li>
		</ul>
	</li>
	<li>&nbsp;</li>
	<li>
		<a href="http://validator.w3.org/check?uri=referer"><img
		src="http://www.w3.org/Icons/valid-xhtml10" border="0"
		alt="Valid XHTML 1.0 Transitional" height="31" width="88" /></a>
	</li>
	<li>
		<a href="http://jigsaw.w3.org/css-validator/">
  		<img style="border:0;width:88px;height:31px"
		src="http://jigsaw.w3.org/css-validator/images/vcss" 
		alt="Valid CSS!" border="0" /></a>
	</li>
</ul>
